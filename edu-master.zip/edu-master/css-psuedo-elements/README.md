# CSS Psuedo Elements Tutorial

This video tutorial covers working with the CSS Psuedo Elements.  We'll take a look at the ::before and ::after psuedo elements alongside ::first-line and ::first-letter. 

## Getting Started

See the video tutorial here: https://youtu.be/0eyCgyWbcHE

## License

This project is licensed under the MIT License