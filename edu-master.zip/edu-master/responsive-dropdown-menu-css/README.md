# Responsive Dropdown Menu (No Javascript)

This repsonsive dropdown menu is built using pure html & css without javascript  

## Getting Started

See the video tutorial here: https://youtu.be/7aGLkT4y4ls

## License

This project is licensed under the MIT License