# Responsive Dropdown Menu (no javascript)

A responsive html & css only dropdown menu (no javascript) that works on both mobile and desktop

## Getting Started

See the video tutorial here: 

## License

This project is licensed under the MIT License