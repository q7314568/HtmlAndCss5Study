# Responsive Navbar

Design a responsive navbar using Flexbox

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=6pidsgeLLzE

## License

This project is licensed under the MIT License