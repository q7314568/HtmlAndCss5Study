# Responsive Pure CSS Menu Tutorial (No Javascript)

Design a responsive css menu without javascript using pure HTML5 and CSS3. It will respond to mobile & tablet breakpoints and uses a mobile first menu approach.  

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=sjrp1FEHnyA&t

## License

This project is licensed under the MIT License