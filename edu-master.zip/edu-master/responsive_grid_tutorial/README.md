# Responsive Web Design using CSS Grid

A responsive web design using HTML5 and CSS3 built using the CSS grid

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=gH3sBOj6CGA&t

## License

This project is licensed under the MIT License