# CSS Psuedo Elements Tutorial

Learn about CSS Conic Gradients and how to apply them to create some awesome gradient effects! 

## Getting Started

See the video tutorial here: https://youtu.be/XMEX9_HvW2k

## License

This project is licensed under the MIT License