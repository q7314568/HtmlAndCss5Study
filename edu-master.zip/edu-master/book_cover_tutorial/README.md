# Book Cover Design Photoshop Template

A Photoshop template used for designing and creating book covers 

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=3LXUk7cR9UI

## License

This project is licensed under the MIT License