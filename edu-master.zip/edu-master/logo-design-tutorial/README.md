# How To Design A Logo

Logo Design How To Presentation Slides 

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=u8L8CcnbI4I

## License

This project is licensed under the MIT License