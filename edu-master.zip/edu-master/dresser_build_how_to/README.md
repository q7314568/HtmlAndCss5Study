# DIY Tall Dresser Plans & Cutlist

Plans and cutlists for the DIY Dresser Build 

## Getting Started

See the video tutorial here: https://www.youtube.com/watch?v=9aDXF1t0zak

## License

This project is licensed under the MIT License