# Design Contact Form HTML & CSS

Learn how to design and code a custom contact form from scratching in this HTML & CSS tutorial.  We'll build all of the HTML elements as well as styling with CSS in this part 1/2 of the series.  Part 2 will focus on adding animations and validations via Javascript! 

## Getting Started

See the video tutorial here: https://youtu.be/JQ_WphOV9VQ

## License

This project is licensed under the MIT License