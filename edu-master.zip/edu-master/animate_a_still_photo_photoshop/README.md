# Animate a Still Photo in Photoshop

Video tutorial for animating a still photo in Adobe Photoshop using the video timeline and render video export

## Getting Started

See the video tutorial here: https://youtu.be/giE4SuC9qWc

## License

This project is licensed under the MIT License